package com.developer.gretongers.model;

import android.view.View;

public interface OnUpdateLayout {
	void updateLayout(View view);
}
