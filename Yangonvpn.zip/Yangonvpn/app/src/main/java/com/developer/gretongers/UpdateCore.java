package com.developer.gretongers;

import android.app.*;
import android.content.*;
import android.os.*;
import android.util.*;


import java.io.*;
import java.net.*;

public class UpdateCore extends AsyncTask<String, String, String> {
    private Context context;
    private Listener listener;
    private HttpURLConnection conn;
    private InputStream is;
    private BufferedReader buffer;
    private String url;

    public interface Listener {
        void onLoading();

        void onCompleted(String config) throws Exception;

        void onCancelled();

        void onException(String ex);
    }

    public UpdateCore(Context context, String url, Listener listener) {
        this.context = context;
        this.url = url;
        this.listener = listener;
    }

    @Override
    protected void onPreExecute() {
        listener.onLoading();
    }

    @Override
    protected String doInBackground(String... args) {
        try {
            String api = url;
            if (!api.startsWith("http")) {
                api = new StringBuilder().append("http://").append(url).toString();
            }
            URL oracle = new URL(api);

            StringBuilder sb = new StringBuilder();
            conn = (HttpURLConnection) oracle.openConnection();
			conn.setConnectTimeout(4000);
			conn.setReadTimeout(2000);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            conn.connect();
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String response;

            while ((response = br.readLine()) != null) {
                sb.append(response);
            }
            conn.disconnect();
            return sb.toString();
        } catch (Exception e) {
            return "error";
        } finally {
            if (buffer != null) {
                try {
                    buffer.close();
                } catch (IOException ignored) {
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException ignored) {

                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
        listener.onCancelled();
    }

    @Override
    protected void onPostExecute(String result) {
        try {
            if (result.equals("error")) {
                listener.onException(result);
            } else {
                listener.onCompleted(result);
            }
        } catch (Exception e) {
            listener.onException(e.getMessage());
        }
    }
}
