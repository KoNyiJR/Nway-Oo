package com.developer.gretongers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.developer.gretongers.config.Settings;
import java.io.InputStream;
import java.util.ArrayList;


public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHoler> {
	
	private ArrayList<PostItemData> DataItem;
	private Context context;
	SharedPreferences sharedPreferences;
	
	public MyAdapter(ArrayList<PostItemData> dataItem, Context context) {
		DataItem = dataItem;
		this.context = context;
	}
	
	//called when another viewHolder is created
	@Override
	public ViewHoler onCreateViewHolder(ViewGroup parent, int viewType) {
		View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.server_layout,parent,false);
		return new ViewHoler(view);
	}
	
	
	//will bind the data to ViewHolder ... Show the actual data to RecyclerView
	@Override
	public void onBindViewHolder(ViewHoler holder, int position) {
		final PostItemData itemData=DataItem.get(position);
		
		
		
		holder.date.setText(itemData.name);
		
		if (itemData.flag.contains("sg")){
			holder.img.setImageResource(R.drawable.sg);
			
		}else
		if (itemData.flag.contains("us")){
			holder.img.setImageResource(R.drawable.us);
			
		}else
		if (itemData.flag.contains("uk")){
			holder.img.setImageResource(R.drawable.uk);
			
		}else
		if (itemData.flag.contains("vn")){
			holder.img.setImageResource(R.drawable.vn);
			
		}else
		
		if (itemData.flag.contains("ph")){
			holder.img.setImageResource(R.drawable.ph);
			
		}else
		if (itemData.flag.contains("my")){
			holder.img.setImageResource(R.drawable.my);
			
		}else
		if (itemData.flag.contains("lr")){
			holder.img.setImageResource(R.drawable.lr);
			
		}else
		if (itemData.flag.contains("kr")){
			holder.img.setImageResource(R.drawable.kr);
			
		}else
		if (itemData.flag.contains("jp")){
			holder.img.setImageResource(R.drawable.jp);
			
		}else
		if (itemData.flag.contains("in")){
			holder.img.setImageResource(R.drawable.in);
			
		}else
		if (itemData.flag.contains("id")){
			holder.img.setImageResource(R.drawable.id);
			
		}else
		if (itemData.flag.contains("hk")){
			holder.img.setImageResource(R.drawable.hk);
			
		}else
		if (itemData.flag.contains("ca")){
			holder.img.setImageResource(R.drawable.ca);
			
		}else
		if (itemData.flag.contains("br")){
			holder.img.setImageResource(R.drawable.br);
			
		}else
		if (itemData.flag.contains("au")){
			holder.img.setImageResource(R.drawable.au);
			
		}else
		if (itemData.flag.contains("mm")){
			holder.img.setImageResource(R.drawable.mm);
			
		}else
		
		{
			
			holder.img.setImageResource(R.drawable.ic_launcher);
		}
		
		// Item click တာ ဖမ်းမယ်
		holder.itemView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View V) {
				
				Settings KOnyi= new Settings(context);
				
				SharedPreferences prefs = KOnyi.getPrefsPrivate();
				SharedPreferences.Editor edit = prefs.edit();
				
				
				edit.putString(Settings.USUARIO_KEY, itemData.username);
				edit.putString(Settings.SENHA_KEY, itemData.password);
				edit.putString(Settings.SERVIDOR_KEY, itemData.serverhost);
				edit.putString(Settings.PROXY_IP_KEY, itemData.serverhost);
				edit.putString(Settings.SERVIDOR_PORTA_KEY, itemData.sshport);
				
				//edit.putString("NYI",itemData.name,itemData.flag);
				
				edit.apply();
				
				
				sharedPreferences=context.getSharedPreferences("KoNyiJR", Context.MODE_PRIVATE);
				
				//	String ad=sharedPreferences.getString("user","");
				//String sif=sharedPreferences.getString("password","");
				
				sharedPreferences.edit().putString("name",itemData.name).apply();
				sharedPreferences.edit().putString("flag",itemData.flag).apply();
				
				
				Toast.makeText(context,itemData.name.toString(),2).show();
				
				
				MainActivity.updateMainViews(context);
				
				
				
				
			}
			
			
			
			
		});
		
	}
	
	@Override
	public int getItemCount() {
		return DataItem.size();
	}
	
	
	public class ViewHoler extends RecyclerView.ViewHolder {
		public TextView date,number;
		//   public TextView live2D,updatetime,value12,set12,twoD12,value4,set4,twoD4,inter930,mod930,inter200,mod200;
		public ImageView img;
		public ViewHoler(View itemView) {
			super(itemView);
			date=(TextView)itemView.findViewById(R.id.servername);
			img=(ImageView)itemView.findViewById(R.id.servercountry);
			// 12 .00PM
			
			
		}
		
		
	}
	
	
	
	
}