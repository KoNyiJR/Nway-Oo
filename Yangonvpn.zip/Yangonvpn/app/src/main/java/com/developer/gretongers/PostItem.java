package com.developer.gretongers;

public class PostItem {
	
	
	public String name="";
	public String flag="";
	public String serverhost="";
	public String sshport="";
	public String username="";
	public String password="";
	
	
	
}