package com.developer.gretongers;

import android.media.MediaPlayer;
import android.net.TrafficStats;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.developer.gretongers.*;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import com.developer.gretongers.fragments.ExitDialogFragment;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.widget.Toast;
import android.view.View;
import android.content.Context;

import com.developer.gretongers.util.Utils;
import android.util.Log;
import android.widget.TextView;
import androidx.core.view.GravityCompat;

//import com.google.android.gms.ads.InterstitialAd;
//import com.google.android.gms.ads.interstitial.InterstitialAd;
//import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.material.textfield.TextInputEditText;
import androidx.drawerlayout.widget.DrawerLayout;
import android.net.Uri;
import android.widget.Button;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import com.developer.gretongers.activities.ConfigGeralActivity;

import android.text.Html;
import androidx.appcompat.app.AlertDialog;
import android.content.pm.PackageInfo;
import com.developer.gretongers.logger.SkStatus;

import android.widget.LinearLayout;
import com.developer.gretongers.fragments.ProxyRemoteDialogFragment;

import android.os.Build;
import android.app.Activity;
import com.developer.gretongers.logger.ConnectionStatus;
import android.os.Handler;
import androidx.core.content.ContextCompat;
import com.developer.gretongers.fragments.ClearConfigDialogFragment;
import com.developer.gretongers.activities.ConfigExportFileActivity;
import com.developer.gretongers.activities.ConfigImportFileActivity;
import com.developer.gretongers.config.Settings;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.os.PersistableBundle;
import android.content.res.Configuration;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatRadioButton;

import com.developer.gretongers.config.ConfigParser;
import androidx.core.app.ActivityCompat;

import android.content.DialogInterface;
import com.developer.gretongers.tunnel.TunnelManagerHelper;
import com.developer.gretongers.activities.AboutActivity;

import androidx.viewpager.widget.ViewPager;

import com.google.android.material.navigation.NavigationView;

import com.developer.gretongers.activities.BaseActivity;
import com.developer.gretongers.tunnel.TunnelUtils;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import com.developer.gretongers.view.PayloadGenerator;
import com.developer.gretongers.model.ExceptionHandler;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.developer.gretongers.adapter.LogsAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import androidx.viewpager.widget.PagerAdapter;
import android.view.ViewGroup;
import com.skyfishjy.library.RippleBackground;
import java.util.List;
import java.util.Arrays;
import com.developer.gretongers.fragments.CustomSNIDialogFragment;
import com.developer.gretongers.fragments.AuthenticationFragment;
import androidx.appcompat.app.AppCompatDelegate;

import java.util.Timer;
import java.util.TimerTask;
//import smartdevelop.ir.eram.showcaseviewlib.config.Gravity;
import com.developer.gretongers.StatisticGraphData;
import com.developer.gretongers.StatisticGraphData.DataTransferStats;


import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class MainActivity extends BaseActivity implements DrawerLayout.DrawerListener,
NavigationView.OnNavigationItemSelectedListener,
View.OnClickListener, SkStatus.StateListener,
DialogInterface.OnClickListener {
	private static final String TAG = MainActivity.class.getSimpleName();
	private static final String UPDATE_VIEWS = "MainUpdate";
	public static final String OPEN_LOGS = "com.speedfusion.ssh:openLogs";
    private Settings mConfig;
	private Toolbar toolbar_main;
	private Handler mHandler;
	private LinearLayout mainLayout;
	private Button starterButton;
	private CardView configMsgLayout;
	private TextView configMsgText;
    private PayloadGenerator paygen;
	private static final String[] tabTitle = {"HOME","LOGS"};
	private LogsAdapter mLogAdapter;
	private RecyclerView logList;
	private ViewPager vp;
	private TabLayout tabs;
    private MenuItem settings;
	private MenuItem ifolder;
    public static boolean isHomeTab = true;
	private CardView tunnelLayout;
	private CardView connectionCardview;
	private TextView tunnelInfo;
	private View payloadLayout;
	private View proxyLayout;
	private View sslLayout;
	private String proxyStr;
    private TextView proxyText;
	private TextInputEditText payloadEdit;
	private TextView sniText;
	private NavigationView drawerNavigationView;
	
	SharedPreferences sharedPreferences;

	private MenuItem auth;

	private MenuItem settingsSSH;
	
	MediaPlayer knjr;
	
	
	TextView byin,byout;
	
	
	private AdView adView,adkonyi;
	AdRequest adRequest;
	//AdRequest adRequest;
//	InterstitialAd	mInterstitialAd;

//	private InterstitialAd interstitial;
	
	private InterstitialAd interstitialAd;
	
	
	private AdView adsBannerView;
	
	
	
	
	
	
	@Override
    protected void onCreate(@Nullable Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);


		mHandler = new Handler();
		mConfig = new Settings(this);
        paygen = new PayloadGenerator(this);
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this)); 
		// se primeira vez
		doLayout();
		IntentFilter filter = new IntentFilter();
		filter.addAction(UPDATE_VIEWS);
		filter.addAction(OPEN_LOGS);
		LocalBroadcastManager.getInstance(this).registerReceiver(mActivityReceiver, filter);

		doUpdateLayout();
		
		//initBytesInAndOut();
		
		//ShowBanner();
		//ShowBanner();
		
		MobileAds.initialize(this, new OnInitializationCompleteListener() {
			@Override
			public void onInitializationComplete(
			@NonNull InitializationStatus initializationStatus) {}
		});
		loadAd();
		
		
		//speed byte send and out
		
		
		
		
	}
	/*void initBytesInAndOut() {
		byin = (TextView) findViewById(R.id.bytes_in);
		byout = (TextView) findViewById(R.id.bytes_out);
		StatisticGraphData.getStatisticData().setDisplayDataTransferStats(true);
	}
	*/
	
	private void doLayout() {
		setContentView(R.layout.activity_main_drawer);
		
		
		 
		
		
		sharedPreferences=this.getSharedPreferences("KoNyiJR", Context.MODE_PRIVATE);
		
		TextView name=findViewById(R.id.servername);
		ImageView country=findViewById(R.id.servercountry);
	//	name.setText(sharedPreferences.getString("name",""));
		
		
		//	String ad=sharedPreferences.getString("user","");
		//String sif=sharedPreferences.getString("password","");
	
		
	
		
		String mode = mConfig.getModoNoturno();
		
		final RippleBackground rippleBackground=(RippleBackground)findViewById(R.id.content);
		rippleBackground.startRippleAnimation();
		
		
		

		if (mode.equals("on")) {
			AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            setTheme(R.style.AppTheme);
		} else {
			AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
			setTheme(R.style.AppTheme);
		}
		toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
		doDrawerMain(toolbar_main);
		setSupportActionBar(toolbar_main);
		doTabs();

		mainLayout = (LinearLayout) findViewById(R.id.activity_mainLinearLayout);
		starterButton = (Button) findViewById(R.id.activity_starterButtonMain);
		starterButton.setOnClickListener(this);
		configMsgLayout = (CardView) findViewById(R.id.activitymainCardView1);
		configMsgText = (TextView) findViewById(R.id.activity_mainMensagemConfigTextView);
		tunnelLayout = (CardView) findViewById(R.id.tunnelCardView);
		 CardView KnServer= (CardView) findViewById(R.id.knserver);
		
		KnServer.setOnClickListener(this);
		tunnelLayout.setOnClickListener(this);
		tunnelInfo = (TextView) findViewById(R.id.activitymainTextView1);
		connectionCardview = (CardView) findViewById(R.id.connection_cardView);
	    proxyText = (TextView) findViewById(R.id.proxyText);
		payloadEdit = (TextInputEditText) findViewById(R.id.payloadEdit);
		
		payloadLayout = (View) findViewById(R.id.payloadLayout);
		proxyLayout = (View) findViewById(R.id.proxyLayout);
		proxyLayout.setOnClickListener(this);
		sslLayout = (View) findViewById(R.id.sslLayout);
		sslLayout.setOnClickListener(this);
		sniText = (TextView) findViewById(R.id.sslText);
		
	}
	
	private synchronized void doSaveData() {
		
		
		
	//	updateHeaderCallback();
	
		TextView name=findViewById(R.id.servername);
		
		name.setText(sharedPreferences.getString("name",""));
		
		ImageView country=findViewById(R.id.servercountry);
		
		
	//	name.setText(sharedPreferences.getString("name",""));
		
		if(sharedPreferences.getString("name","").equals("")){
			name.setText("Server Update");
		}else { name.setText(sharedPreferences.getString("name",""));}
		
		
		
		if (sharedPreferences.getString("flag","").contains("sg")){
			country.setImageResource(R.drawable.sg);
			
		}else
		if (sharedPreferences.getString("flag","").contains("us")){
			country.setImageResource(R.drawable.us);
			
		}else
		if (sharedPreferences.getString("flag","").contains("uk")){
			country.setImageResource(R.drawable.uk);
			
		}else
		if (sharedPreferences.getString("flag","").contains("vn")){
			country.setImageResource(R.drawable.vn);
			
		}else
		
		if (sharedPreferences.getString("flag","").contains("ph")){
			country.setImageResource(R.drawable.ph);
			
		}else
		if (sharedPreferences.getString("flag","").contains("my")){
			country.setImageResource(R.drawable.my);
			
		}else
		if (sharedPreferences.getString("flag","").contains("lr")){
			country.setImageResource(R.drawable.lr);
			
		}else
		if (sharedPreferences.getString("flag","").contains("kr")){
			country.setImageResource(R.drawable.kr);
			
		}else
		if (sharedPreferences.getString("flag","").contains("jp")){
			country.setImageResource(R.drawable.jp);
			
		}else
		if (sharedPreferences.getString("flag","").contains("in")){
			country.setImageResource(R.drawable.in);
			
		}else
		if (sharedPreferences.getString("flag","").contains("id")){
			country.setImageResource(R.drawable.id);
			
		}else
		if (sharedPreferences.getString("flag","").contains("hk")){
			country.setImageResource(R.drawable.hk);
			
		}else
		if (sharedPreferences.getString("flag","").contains("ca")){
			country.setImageResource(R.drawable.ca);
			
		}else
		if (sharedPreferences.getString("flag","").contains("br")){
			country.setImageResource(R.drawable.br);
			
		}else
		if (sharedPreferences.getString("flag","").contains("au")){
			country.setImageResource(R.drawable.au);
			
		}else
		
		if (sharedPreferences.getString("flag","").contains("mm")){
			country.setImageResource(R.drawable.mm);
			
		}else
		
		{
			
			country.setImageResource(R.drawable.ic_launcher);
		}
		
		
		
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		SharedPreferences.Editor edit = prefs.edit();
		if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			if (payloadEdit != null && !prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
				if (mainLayout != null)
					mainLayout.requestFocus();
				edit.putString(Settings.CUSTOM_PAYLOAD_KEY, payloadEdit.getText().toString());
			}
		}
		int tunnelType = prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
		if (tunnelType == Settings.bTUNNEL_TYPE_SLOWDNS) {
			edit.putString(Settings.SERVIDOR_KEY, "127.0.0.1");
			edit.putString(Settings.SERVIDOR_PORTA_KEY, "8989");

		}
		edit.apply();
	}

    private void doUpdateLayout() {
        SharedPreferences prefs = mConfig.getPrefsPrivate();
        boolean isRunning = SkStatus.isTunnelActive();
        setStarterButton(starterButton, this);
        boolean protect = prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false);
        String proxy = mConfig.getPrivString(Settings.PROXY_IP_KEY);

        int msgVisibility = View.GONE;
        String msgText = "";

        if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {    
            String msg = mConfig.getPrivString(Settings.CONFIG_MENSAGEM_KEY);
            if (!msg.isEmpty()) {
                msgText = msg.replace("\n", "<br/>");
                msgVisibility = View.VISIBLE;
            }

            if (mConfig.getPrivString(Settings.PROXY_IP_KEY).isEmpty() ||
                mConfig.getPrivString(Settings.PROXY_PORTA_KEY).isEmpty()) {
            }
        }
        configMsgText.setText(msgText.isEmpty() ? "" : Html.fromHtml(msgText));
        configMsgLayout.setVisibility(msgVisibility);

        if (mConfig.getPrivString("enable_auth").equals("_true")) {
            Menu menuNav = drawerNavigationView.getMenu();
           // auth = menuNav.findItem(R.id.authentication);
          //  auth.setVisible(true);
        } else {
           //Menu menuNav = drawerNavigationView.getMenu();
           // auth = menuNav.findItem(R.id.authentication);
           // auth.setVisible(false);
        }
        if (prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
            proxyText.setText("******");
            proxyLayout.setEnabled(false);
        } else {
            proxyLayout.setEnabled(!isRunning);
            if (proxy.equals("")) { 
                proxyText.setText(R.string.squid);
            }  else {
                proxyText.setText(String.format("%s:%s", proxy, mConfig.getPrivString(Settings.PROXY_PORTA_KEY)));
            }
      
}
        }

    private void generator(){
		paygen.setDialogTitle(getString(R.string.pay_gen));
		paygen.setCancelListener(getString(R.string.cancel), new PayloadGenerator.OnCancelListener(){

                @Override
                public void onCancelListener() {
                }
            });
        paygen.setGenerateListener(getString(R.string.gen), new PayloadGenerator.OnGenerateListener(){

                @Override
                public void onGenerate(String payloadGenerated) {              
					SharedPreferences prefs = mConfig.getPrefsPrivate();
					if (!prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)){
						payloadEdit.setText(payloadGenerated);     
					} else {
						Toast.makeText(MainActivity.this, R.string.custom_payload_msg, Toast.LENGTH_SHORT).show();
					}                                              
				}
            });
        paygen.show();
	}
	
	/**
	 * Tunnel SSH
	 */

	public void doTabs() {
	/*	LinearLayoutManager layoutManager = new LinearLayoutManager(this);
		//deleteLogs = (FloatingActionButton)findViewById(R.id.delete_log);
		mLogAdapter = new LogsAdapter(layoutManager,this);
		logList = (RecyclerView) findViewById(R.id.recyclerLog);
		logList.setAdapter(mLogAdapter);
		logList.setLayoutManager(layoutManager);
		mLogAdapter.scrollToLastPosition();
		vp = (ViewPager)findViewById(R.id.viewpager);
		tabs = (TabLayout)findViewById(R.id.tablayout);
		vp.setAdapter(new MyAdapter(Arrays.asList(tabTitle)));
		vp.setOffscreenPageLimit(2);
		tabs.setTabMode(TabLayout.MODE_FIXED);
		tabs.setTabGravity(TabLayout.GRAVITY_FILL);
		tabs.setupWithViewPager(vp);
        vp.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener()
            {
                @Override
                public void onPageSelected(int position)
                {
                    if (position == 0) {
                        settings.setIcon(R.drawable.ic_settings);                   
                        ifolder.setVisible(true);
                        ifolder.setIcon(R.drawable.ic_config);
                        isHomeTab = true;
                    } else if (position == 1) {                                        
						ifolder.setVisible(false);
                        settings.setIcon(R.drawable.ic_delete_forever_white_24dp);
                        isHomeTab = false;
                    }
                }
			});
*/
	}

	public class MyAdapter extends PagerAdapter {

		@Override
		public int getCount() {
			// TODO: Implement this method
			return 2;
		}

		@Override
		public boolean isViewFromObject(View p1, Object p2) {
			// TODO: Implement this method
			return p1 == p2;
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			int[] ids = new int[]{R.id.tab1, R.id.tab2};
			int id = 0;
			id = ids[position];
			// TODO: Implement this method
			return findViewById(id);
		}

		@Override
		public CharSequence getPageTitle(int position)
		{
			// TODO: Implement this method
			return titles.get(position);
		}

		private List<String> titles;
		public MyAdapter(List<String> str)
		{
			titles = str;
		}
	}
	
	
	public void startOrStopTunnel(Activity activity) {
		
		TextView ser=findViewById(R.id.servername);
		
		
		if(ser.getText().toString().equals("Server Update")){
			
			
			Intent intentnyi = new Intent(activity, KNActivity.class);
			activity.startActivity(intentnyi);
			
		}else{
		
		
		if (SkStatus.isTunnelActive()) {
			TunnelManagerHelper.stopSocksHttp(activity);
		}
		else {
			// oculta teclado se vísivel, tá com bug, tela verde
			//Utils.hideKeyboard(activity);
			Settings config = new Settings(activity);
			Intent intent = new Intent(activity, LaunchVpn.class);
			intent.setAction(Intent.ACTION_MAIN);
			if (config.getHideLog()) {
				intent.putExtra(LaunchVpn.EXTRA_HIDELOG, true);
			}
			activity.startActivity(intent);
		}
		
		}
	}

	public void setStarterButton(Button starterButton, Activity activity) {
		String state = SkStatus.getLastState();
		boolean isRunning = SkStatus.isTunnelActive();

		if (starterButton != null) {
			int resId;
			SharedPreferences prefsPrivate = new Settings(activity).getPrefsPrivate();
			if (ConfigParser.isValidadeExpirou(prefsPrivate
											   .getLong(Settings.CONFIG_VALIDADE_KEY, 0))) {
				resId = R.string.expired;
				starterButton.setEnabled(false);
				if (isRunning) {
					startOrStopTunnel(activity);              
				}
			}
			else if (prefsPrivate.getBoolean(Settings.BLOQUEAR_ROOT_KEY, false) &&
					 ConfigParser.isDeviceRooted(activity)) {
				resId = R.string.blocked;
				starterButton.setEnabled(false);

				Toast.makeText(activity, R.string.error_root_detected, Toast.LENGTH_SHORT)
					.show();

				if (isRunning) {
					startOrStopTunnel(activity);
				}
			}
			else if (SkStatus.SSH_STARTING.equals(state)) {
				resId = R.string.stop;
				starterButton.setEnabled(false);
			} else if (SkStatus.SSH_STOPPING.equals(state)) {           
				resId = R.string.state_stopping;
				starterButton.setEnabled(false);
			}
			else {
				resId = isRunning ? R.string.stop : R.string.start;
				starterButton.setEnabled(true);
			}

			starterButton.setText("");
		}
	}


	/**
	 * Drawer Main
	 */

	private DrawerLayout drawerLayout;
	private ActionBarDrawerToggle toggle;

	public void doDrawerMain(Toolbar toolbar) {
	    drawerNavigationView = (NavigationView) findViewById(R.id.drawerNavigationView);
		drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayoutMain);

		// set drawer
		toggle = new ActionBarDrawerToggle(this,
										   drawerLayout, toolbar, R.string.open, R.string.cancel);

        drawerLayout.setDrawerListener(toggle);

		toggle.syncState();

		// set app info
		PackageInfo pinfo = Utils.getAppInfo(this);
		if (pinfo != null) {
			String version_nome = pinfo.versionName;
			int version_code = pinfo.versionCode;
			String header_text = String.format("%s (%d)", version_nome, version_code);

			View view = drawerNavigationView.getHeaderView(0);

			TextView app_info_text = view.findViewById(R.id.nav_headerAppVersion);
			app_info_text.setText(header_text);
		}

		// set navigation view
		drawerNavigationView.setNavigationItemSelectedListener(this);
	}

	@Override
    public void onPostCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onPostCreate(savedInstanceState, persistentState);
        if (toggle != null)
			toggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (toggle != null)
			toggle.onConfigurationChanged(newConfig);
    }
	
	@Override
	public void onClick(View p1) {
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		boolean isRunning = SkStatus.isTunnelActive();
		switch (p1.getId()) {
			case R.id.activity_starterButtonMain:
				doSaveData();
				startOrStopTunnel(this);
				
				
				
				break;
				
			case R.id.tunnelCardView:
				if (!isRunning) {
					if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
			      	startActivity(new Intent(this, TunnelActivity.class));
				    }
				}
			   break;
			   
			   
			   
			   case R.id.knserver:
			   if (!isRunning) {
				   if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
					   startActivity(new Intent(this, KNActivity.class));
				   }
			   }
			   break;
			   
			   
			 case R.id.proxyLayout:
				doSaveData();
				 if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
					 if (!isRunning) {
					DialogFragment fragProxy = new ProxyRemoteDialogFragment();
					fragProxy.show(getSupportFragmentManager(), "proxyDialog");
					}
				}
			  break;
			  
			  case R.id.sslLayout:
				doSaveData();
				if (!prefs.getBoolean(Settings.CONFIG_PROTEGER_KEY, false)) {
					if (!isRunning) {
						DialogFragment fragProxy = new CustomSNIDialogFragment();
						fragProxy.show(getSupportFragmentManager(), "sni");
					}
				}
			  break;
		}
	}
	
	@Override
	public void onClick(DialogInterface p1, int p2) {
		switch (p2) {
			/*case p1.BUTTON_POSITIVE:
				// tudo ok
				break;*/
		}
	}

	@Override
	public void updateState(final String state, String msg, int localizedResId, final ConnectionStatus level, Intent intent) {
		mHandler.post(new Runnable() {
				@Override
				public void run() {
					doUpdateLayout();
					
					TextView status=findViewById(R.id.knstate);
					
					
					//TextView status=findViewById(R.id.knstate);
					
					if (SkStatus.isTunnelActive()){
						
						
						
						if (level.equals(ConnectionStatus.LEVEL_CONNECTED)){
							status.setText("Connected");
							
							//updateHeaderCallback();
							ShowBanner();
							
							showInterstitial();
							
							
						//	knjr=MediaPlayer.creat(this,R.raw.kn);
							
						//	knjr.start();
						}
						
						if (level.equals(ConnectionStatus.LEVEL_NOTCONNECTED)){
							status.setText("Disconnected");
						}
						
						if (level.equals(ConnectionStatus.LEVEL_CONNECTING_SERVER_REPLIED)){
							status.setText("Authenticating");
						}
						
						if (level.equals(ConnectionStatus.LEVEL_CONNECTING_NO_SERVER_REPLY_YET)){
							status.setText("Connecting");
						}
						if (level.equals(ConnectionStatus.LEVEL_AUTH_FAILED)){
							status.setText("Authfailed");
						}
						if (level.equals(ConnectionStatus.UNKNOWN_LEVEL)){
							status.setText("Disconnected");
						}
					
					
					}
				}
			});

		switch (state) {
			case SkStatus.SSH_CONNECTED:
				mHandler.postDelayed(new Runnable() {
						@Override
						public void run() {
							
						//	updateHeaderCallback();
						}
					}, 1000);
				break;
		}
	}


	/**
	 * Recebe locais Broadcast
	 */

	private BroadcastReceiver mActivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null)
                return;

            if (action.equals(UPDATE_VIEWS)) {
				doUpdateLayout();
			}
			else if (action.equals(OPEN_LOGS)) {
					if (!drawerLayout.isDrawerOpen(GravityCompat.END)) {
						drawerLayout.openDrawer(GravityCompat.END);
					}
				}
			}
    };


	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
		settings= menu.findItem(R.id.miSettings);
	//	ifolder = menu.findItem(R.id.folder);
        return true;
		
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		SharedPreferences prefs = mConfig.getPrefsPrivate();
		int tunnelType = prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);
		
		if (toggle != null && toggle.onOptionsItemSelected(item)) {
            return true;
        }

		// Menu Itens
		switch (item.getItemId()) {
			

			case R.id.miSettings:
				if (isHomeTab == true) {
                    Intent intentSettings = new Intent(this, ConfigGeralActivity.class);
                    //intentSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intentSettings);
                } 
				break;

		
			case R.id.miLimparLogs:
				break;

			case R.id.miExit:
				if (Build.VERSION.SDK_INT >= 16) {
					finishAffinity();
				}
				System.exit(0);
				break;
		}

		return super.onOptionsItemSelected(item);
	}

	@Override
	public boolean onNavigationItemSelected(@NonNull MenuItem item) {
		int id = item.getItemId();
	    switch(id) {  
        
        
            
           
			case R.id.miPhoneConfg:
				PackageInfo app_info = Utils.getAppInfo(getApplicationContext());
				if (app_info != null) {
					String aparelho_marca = Build.BRAND.toUpperCase();
					if (aparelho_marca.equals("SAMSUNG") || aparelho_marca.equals("HUAWEY")) {
						Toast.makeText(getApplicationContext(), R.string.error_no_supported, Toast.LENGTH_SHORT)
							.show();
					}
					else {
						try {
							Intent in = new Intent(Intent.ACTION_MAIN);
							in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
							in.setClassName("com.android.settings", "com.android.settings.RadioInfo");
							startActivity(in);
						} catch(Exception e) {
							Toast.makeText(getApplicationContext(), R.string.error_no_supported, Toast.LENGTH_SHORT)
								.show();
						}
					}
				}
				break;

			case R.id.miSettings:
				Intent intent = new Intent(MainActivity.this, ConfigGeralActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
				break;

            
          /*  case R.id.speedtest:    
                Intent speedtestintent = new Intent(MainActivity.this, speedtest.class);
                startActivity(speedtestintent);
                break; 
				*/
			
				
			
			case R.id.miAbout:
                Intent aboutIntent = new Intent(this, AboutActivity.class);
				startActivity(aboutIntent);
				break;
		} if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
			drawerLayout.closeDrawers();
		}
		return true;
	}

	@Override
	public void onBackPressed() {
		
		if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
			
			
			TextView name=findViewById(R.id.servername);
			name.setText(sharedPreferences.getString("name",""));
			
			
            drawerLayout.closeDrawers();
        }
		
		else {
			// mostra opção para sair
			new ExitDialogFragment(this)
				.show(getSupportFragmentManager(), "alertExit");
		}
	}

	@Override
    public void onResume() {
        super.onResume();
		SkStatus.addStateListener(this);
		doSaveData();
		
		
	/*	new Timer().schedule(new TimerTask()
		{
			@Override
			public void run()
			{
				runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
					//	updateHeaderCallback();
					}
				});
			}
		}, 0,1000);*/
		
		
	
    }

	@Override
	protected void onPause()
	{
		super.onPause();

		SkStatus.removeStateListener(this);

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		doSaveData();
		LocalBroadcastManager.getInstance(this)
			.unregisterReceiver(mActivityReceiver);

	}


	/**
	 * DrawerLayout Listener
	 */

	@Override
	public void onDrawerOpened(View view) {
		
	}

	@Override
	public void onDrawerClosed(View view) {
		
	}

	@Override
	public void onDrawerStateChanged(int stateId) {}
	@Override
	public void onDrawerSlide(View view, float p2) {}


	/**
	 * Utils
	 */

	public static void updateMainViews(Context context) {
		Intent updateView = new Intent(UPDATE_VIEWS);
		LocalBroadcastManager.getInstance(context).sendBroadcast(updateView);
	}

/*
private void fixbykn() {
	
	final Handler handler = new Handler();
	handler.postDelayed(new Runnable() {
		@Override
		public void run() {
			
			updateHeaderCallback();
			
		}
		
		
	}, 1000);

}

private void updateHeaderCallback() {
	
	fixbykn();
	DataTransferStats dataTransferStats = StatisticGraphData.getStatisticData().getDataTransferStats();
	byin.setText(dataTransferStats.byteCountToDisplaySize(dataTransferStats.getTotalBytesReceived(), true));
	byout.setText(dataTransferStats.byteCountToDisplaySize(dataTransferStats.getTotalBytesSent(), true));
}
*/


private void ShowBanner(){
	
	adkonyi=(AdView)
			findViewById(R.id.ad_viewkonyi);
	
	adView = (AdView)
	findViewById(R.id.ad_view);
	//adView = (AdView)
	//  findViewById(R.id.ad_view);
	adRequest = new AdRequest.Builder().build();
	
	
	adView.loadAd(adRequest);
	adkonyi.loadAd(adRequest);
}


private void showInterstitial() {
	if (interstitialAd != null) {
		interstitialAd.show(this);
		} else {
		 loadAd();
		//Toast.makeText(this, "Ad did not load", Toast.LENGTH_SHORT).show();
	}
}

private void loadAd() {
	AdRequest adRequest = new AdRequest.Builder().build();
	InterstitialAd.load(this, "ca-app-pub-1754761721069694/6558306312", adRequest,
	new InterstitialAdLoadCallback() {
		@Override
		public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
			// The mInterstitialAd reference will be null until
			// an ad is loaded.
			MainActivity.this.interstitialAd = interstitialAd;
			//Log.i(TAG, "onAdLoaded");
			//Toast.makeText(MainActivity.this, "onAdLoaded()", Toast.LENGTH_SHORT).show();
			interstitialAd.setFullScreenContentCallback(
			new FullScreenContentCallback() {
				@Override
				public void onAdDismissedFullScreenContent() {
					// Called when fullscreen content is dismissed.
					// Make sure to set your reference to null so you don't
					// show it a second time.
					loadAd();
					
					MainActivity.this.interstitialAd = null;
					//Log.d("TAG", "The ad was dismissed.");
				}
				
				@Override
				public void onAdFailedToShowFullScreenContent(AdError adError) {
					// Called when fullscreen content failed to show.
					// Make sure to set your reference to null so you don't
					// show it a second time.
					loadAd();
					MainActivity.this.interstitialAd = null;
					//Log.d("TAG", "The ad failed to show.");
				}
				
				@Override
				public void onAdShowedFullScreenContent() {
					// Called when fullscreen content is shown.
					//Log.d("TAG", "The ad was shown.");
				}
			});
		}
		
		@Override
		public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
			// Handle the error
			//Log.i(TAG, loadAdError.getMessage());
			interstitialAd = null;
			String error = String.format("domain: %s, code: %d, message: %s", loadAdError.getDomain(), loadAdError.getCode(), loadAdError.getMessage());
			/* Toast.makeText(
			MainActivity.this, "onAdFailedToLoad() with error: " + error, Toast.LENGTH_SHORT)
			.show();*/
		}
	});
}
}
 /*
private Handler mHandler2 = new Handler();
private long mStartRX = 0;
private long mStartTX = 0;
private final Runnable mRunnable = new Runnable() {
	public void run() {
		TextView byin = (TextView) findViewById(R.id.bytes_in);
		TextView byout = (TextView) findViewById(R.id.bytes_out);
		long resetdownload=TrafficStats.getTotalRxBytes();
		
		long rxBytes = TrafficStats.getTotalRxBytes() - mStartRX;
		
		byin.setText(Long.toString(rxBytes)+ " bytes");
		if (rxBytes >= 1024) {
			
			long rxKb = rxBytes / 1024;
			
			byin.setText(Long.toString(rxKb)+ " KB");
			if (rxKb >= 1024) {
				
				long rxMB = rxKb / 1024;
				
				byin.setText(Long.toString(rxMB)+ " MB");
				if (rxMB >= 1024) {
					
					long rxGB = rxMB / 1024;
					
					byin.setText(Long.toString(rxGB) + " GB");
				}
			}
		}
		
		mStartRX=resetdownload;
		
		long resetupload=TrafficStats.getTotalTxBytes();
		
		long txBytes = TrafficStats.getTotalTxBytes() - mStartTX;
		
		byout.setText(Long.toString(txBytes)+ " bytes");
		if (txBytes >= 1024) {
			
			long txKb = txBytes / 1024;
			
			byout.setText(Long.toString(txKb)+ " KB");
			if (txKb >= 1024) {
				
				long txMB = txKb / 1024;
				
				byout.setText(Long.toString(txMB)+ " MB");
				if (txMB >= 1024) {
					
					long txGB = txMB / 1024;
					
					byout.setText(Long.toString(txGB)+ " GB");
				}
			}
		}
		
		mStartTX=resetupload;
		
		mHandler2.postDelayed(mRunnable, 1000);
	}
};
}
*/

