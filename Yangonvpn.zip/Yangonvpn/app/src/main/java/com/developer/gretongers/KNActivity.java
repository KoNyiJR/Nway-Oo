package com.developer.gretongers;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.NetworkInfo;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.developer.gretongers.*;
import com.developer.gretongers.config.Settings;
import com.developer.gretongers.view.MaterialButton;
import android.view.Menu;
import android.view.MenuItem;
import com.developer.gretongers.logger.SkStatus;
import android.widget.Toast;

import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;




public class KNActivity extends AppCompatActivity {	
	
	private Toolbar toolbar_main;
	
	boolean online=true;
	private RecyclerView recyclerView;
	private RecyclerView.Adapter adapter;
	private ArrayList<PostItemData> itemsData;
	
	SharedPreferences sharedPreferences;
	
	FeedAdapter KKN;
	List<PostItem> posts,filteredposts;
	
	private AdView adView;
	AdRequest adRequest;
	//AdRequest adRequest;
			@Override
		protected void onCreate(Bundle savedInstanceState) {
			// TODO: Implement this method
			super.onCreate(savedInstanceState);
			setContentView(R.layout.thaesukhaing);
		
		toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
		setSupportActionBar(toolbar_main);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		recyclerView=findViewById(R.id.recycler);
		recyclerView.setHasFixedSize(true);
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
		
//	LoadRecyclerViewData();
	
	
	knreload();
	
	
	
	}
	
	
	public void thaesu(View v){
		
		
		knreload();
		
	}
	
	
	
	
	private  void knreload(){
	
	if(isOnline()){
		online=true;
	
		try{
			String  lucky = Dec.decrypt(Dec.bArr, "ikFzjzgy+tkxD9GAIcw5fs7WiG04ZsK97QpJy5HN5ymKP6BcDqPHkHIQqQ2UMbK2DaUj9ZRlU0PuuZMjLeRRzX6SBX8/zaPzqG89EFSERAg=");
			
			
			
			
			new DownloadTask().execute(lucky);
			
			//checkversion();
			
			adView = (AdView)
			findViewById(R.id.ad_view);
			//adView = (AdView)
			//  findViewById(R.id.ad_view);
			adRequest = new AdRequest.Builder().build();
			
			
			adView.loadAd(adRequest);
			
			adView.setVisibility(View.VISIBLE);
			
			
		}
		
		catch(GeneralSecurityException e){
			
			Toast.makeText(getApplicationContext(),"Password Not Found.ðŸ˜«",Toast.LENGTH_SHORT).show();
			
		}
		
		}else{
			
			
		online=false;
		
		adView = (AdView)
		findViewById(R.id.ad_view);
		adView.setVisibility(View.GONE);
		
		Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_SHORT).show();
		SharedPreferences sharedPreferences = getSharedPreferences("konyi", Context.MODE_PRIVATE);
		String lastDatakn= sharedPreferences.getString("vip","");
		
			processJsonkonyi(lastDatakn);
			
			
			//nn=new FeedAdapter();
		//recyclerView.setAdapter(adapter);
			
	
		//	Toast.makeText(this,e.toString(),Toast.LENGTH_SHORT).show();
		}
	}
	
	
	
	
	
	private class DownloadTask extends AsyncTask<String, Void, String>
	{
		@Override
		protected void onPreExecute() {
			//mSwipeLayout.setRefreshing(true);
		}
		
		@Override
		protected String doInBackground(String... p1)
		{
			String result=JSONDownloader.download(p1[0]);
			return result;
		}
		
		@Override
		public void onPostExecute(String result) {
			
			
			processJson(result);
			
		}
	}
	
	
	
	public void processJson(String inputJson){
		
	//	itemsData=new ArrayList<>();
		try
		{
			JSONObject obj=new JSONObject(inputJson);
		//	JSONArray jarr=new JSONArray(inputJson);
			JSONArray jarr=obj.getJSONArray("knserver");
			
			String version =obj.getString("version");
			
			for(int j=0;j<jarr.length();j++){
			
			String name=(jarr.getJSONObject(j).getString("name"));
			String flag=(jarr.getJSONObject(j).getString("flag"));
			
			String serverhost=(jarr.getJSONObject(j).getString("serverhost"));
			String sshport=(jarr.getJSONObject(j).getString("sshport"));
			
			String username=(jarr.getJSONObject(j).getString("username"));
			String password=(jarr.getJSONObject(j).getString("password"));
			
			 
			
			//	String image=(jarr.getJSONObject(j).getString("image"));
			//p.des=(jarr.getJSONObject(j).getString("des"));
			
			//PostItemData itemData=new PostItemData(name,flag,serverhost,sshport,username,password);
			
			
			//itemsData.add(itemData);
			
			
			// save version
			
			SharedPreferences sharedPreferencesko = getSharedPreferences("konyi", Context.MODE_PRIVATE);
			//String lastDatakn= sharedPreferencesko.getString("vip","");
			
			
			
			if(sharedPreferencesko.getString("knversion","").equals(version)){
				
			SharedPreferences sharedPreferenceskonyi = getSharedPreferences("konyi", Context.MODE_PRIVATE);
			String lastDatakn= sharedPreferenceskonyi.getString("vip","");
			
			processJsonkonyi(lastDatakn);
			
		//	nn=new FeedAdapter();
			//recyclerView.setAdapter(adapter);
			
			
			
			
			
			
			}else {
				
				SharedPreferences sharedPreferences = getSharedPreferences("konyi", Context.MODE_PRIVATE);
				SharedPreferences.Editor editor = sharedPreferences.edit();
				editor.putString("knversion",version);
				
				editor.putString("vip",inputJson);
				editor.commit();
				
				processJsonkonyi(inputJson);
				
				
			//	nn=new FeedAdapter();
				//recyclerView.setAdapter(adapter);
				
				
				
				
				
				
				//adapter=new MyAdapter(itemsData,getApplicationContext());
				//recyclerView.setAdapter(adapter);
				
			}
				
				
				}
			//	adapter=new MyAdapter(itemsData,getApplicationContext());
				//recyclerView.setAdapter(adapter);
				
			}	catch (JSONException e)
				{
				}
			}
			
			
			
			
			
			protected boolean isOnline() {
				ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
				NetworkInfo netInfo = cm.getActiveNetworkInfo();
				if (netInfo != null && netInfo.isConnectedOrConnecting()) {
					return true;
					} else {
					return false;
				}
			}
			
			
			
			
			
			
			
			@Override
			public boolean onOptionsItemSelected(MenuItem item)
			{
				if(item.getItemId()==android.R.id.home){
					finish();
					
					
					
					
				}
				return super.onOptionsItemSelected(item);
			}
			
			
			
		public void processJsonkonyi(String inputJson){
			
			itemsData=new ArrayList<>();
			
			
			posts=new ArrayList<PostItem>();
			filteredposts=new ArrayList<PostItem>();
			
			
			try
			{
				JSONObject obj=new JSONObject(inputJson);
				//	JSONArray jarr=new JSONArray(inputJson);
				JSONArray jarr=obj.getJSONArray("knserver");
				
				String version =obj.getString("version");
				
				for(int j=0;j<jarr.length();j++){
					
					
					PostItem pi=new PostItem();
					
					pi.name=(jarr.getJSONObject(j).getString("name"));
					pi.flag=(jarr.getJSONObject(j).getString("flag"));
					
					pi.serverhost=(jarr.getJSONObject(j).getString("serverhost"));
					pi.sshport=(jarr.getJSONObject(j).getString("sshport"));
					
					pi.username=(jarr.getJSONObject(j).getString("username"));
					pi.password=(jarr.getJSONObject(j).getString("password"));
					
					
					addItem(pi);
					//	String image=(jarr.getJSONObject(j).getString("image"));
					//p.des=(jarr.getJSONObject(j).getString("des"));
					
				//	PostItemData itemData=new PostItemData(name,flag,serverhost,sshport,username,password);
					
					
				//	itemsData.add(itemData);
					
					
					// save version
					}
					
						//adapter=new MyAdapter(itemsData,getApplicationContext());
					//	recyclerView.setAdapter(adapter);
						KKN = new FeedAdapter();
						recyclerView.setAdapter(KKN);
					
					
					
				
				//	adapter=new MyAdapter(itemsData,getApplicationContext());
				//recyclerView.setAdapter(adapter);
				
			}	catch (JSONException e)
			{
			}
		}
		
		
		
		
		public void addItem(PostItem item){
			posts.add(item);
		}
		
		public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ViewHolder>
		{
			@Override
			public void onAttachedToRecyclerView(RecyclerView arg0) {
				super.onAttachedToRecyclerView(arg0);
			}

			@Override
			public FeedAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
			{
				View v=getLayoutInflater().inflate(R.layout.server_layout,p1,false);
				return new ViewHolder(v);
			}
			
			
			@Override
			public int getItemCount()
			{
				return filteredposts.size();
			}
			
			@Override
			public void onBindViewHolder(FeedAdapter.ViewHolder holder, int p2)
			{
				// adapter code with layout
				
			holder.tv.setText(filteredposts.get(p2).name);
			
				if (filteredposts.get(p2).flag.contains("sg")){
					holder.img.setImageResource(R.drawable.sg);
					
				}else
				if (filteredposts.get(p2).flag.contains("us")){
					holder.img.setImageResource(R.drawable.us);
					
				}else
				if (filteredposts.get(p2).flag.contains("uk")){
					holder.img.setImageResource(R.drawable.uk);
					
				}else
				if (filteredposts.get(p2).flag.contains("vn")){
					holder.img.setImageResource(R.drawable.vn);
					
				}else
				
				if (filteredposts.get(p2).flag.contains("ph")){
					holder.img.setImageResource(R.drawable.ph);
					
				}else
				if (filteredposts.get(p2).flag.contains("my")){
					holder.img.setImageResource(R.drawable.my);
					
				}else
				if (filteredposts.get(p2).flag.contains("lr")){
					holder.img.setImageResource(R.drawable.lr);
					
				}else
				if (filteredposts.get(p2).flag.contains("kr")){
					holder.img.setImageResource(R.drawable.kr);
					
				}else
				if (filteredposts.get(p2).flag.contains("jp")){
					holder.img.setImageResource(R.drawable.jp);
					
				}else
				if (filteredposts.get(p2).flag.contains("in")){
					holder.img.setImageResource(R.drawable.in);
					
				}else
				if (filteredposts.get(p2).flag.contains("id")){
					holder.img.setImageResource(R.drawable.id);
					
				}else
				if (filteredposts.get(p2).flag.contains("hk")){
					holder.img.setImageResource(R.drawable.hk);
					
				}else
				if (filteredposts.get(p2).flag.contains("ca")){
					holder.img.setImageResource(R.drawable.ca);
					
				}else
				if (filteredposts.get(p2).flag.contains("br")){
					holder.img.setImageResource(R.drawable.br);
					
				}else
				if (filteredposts.get(p2).flag.contains("au")){
					holder.img.setImageResource(R.drawable.au);
					
				}else
				if (filteredposts.get(p2).flag.contains("mm")){
					holder.img.setImageResource(R.drawable.mm);
					
				}else
				
				{
					
					holder.img.setImageResource(R.drawable.ic_launcher);
				}
				
				
				
				
				
				
				}
			public PostItem getItem(int pos){
				return filteredposts.get(pos);
			}
			
			public void reset()
			{
				posts.clear();
				filteredposts.clear();
				notifyDataSetChanged();
			}
			
			public FeedAdapter()
			{
				super();
				filteredposts=new ArrayList<PostItem>();
				filteredposts.addAll(posts);
			}
			
			public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
			{
				ImageView img;
				TextView tv;
				
				@Override
				public void onClick(View view)
				{
					
					PostItem pi=filteredposts.get(getAdapterPosition());
					
					// StartAppAd.showAd(JSONFeedActivity.this);
					
					//  DisplayUnityInterstitialAd();
					// showInterstitial();
				//	ShowAdsType();
					
					Settings KOnyi= new Settings(KNActivity.this);
					
					SharedPreferences prefs = KOnyi.getPrefsPrivate();
					SharedPreferences.Editor edit = prefs.edit();
					
					
					edit.putString(Settings.USUARIO_KEY, pi.username);
					edit.putString(Settings.SENHA_KEY, pi.password);
					edit.putString(Settings.SERVIDOR_KEY, pi.serverhost);
					edit.putString(Settings.PROXY_IP_KEY, pi.serverhost);
					edit.putString(Settings.SERVIDOR_PORTA_KEY, pi.sshport);
					
					//edit.putString("NYI",itemData.name,itemData.flag);
					
					edit.apply();
					
					
					sharedPreferences=KNActivity.this.getSharedPreferences("KoNyiJR", Context.MODE_PRIVATE);
					
					//	String ad=sharedPreferences.getString("user","");
					//String sif=sharedPreferences.getString("password","");
					
					sharedPreferences.edit().putString("name",pi.name).apply();
					sharedPreferences.edit().putString("flag",pi.flag).apply();
					
					
				//	Toast.makeText(context,itemData.name.toString(),2).show();
					
					
					//MainActivity.updateMainViews(context);
					
					
				
				
					Intent i=new Intent(KNActivity.this,MainActivity.class);
				//	PostItem pi=filteredposts.get(getAdapterPosition());
				//	i.putExtra("title",pi.title);
				//	i.putExtra("content",pi.content);
					finish();
					startActivity(i);
				}
				public ViewHolder(View view)
				{
					super(view);
					img=view.findViewById(R.id.servercountry);
					tv=view.findViewById(R.id.servername);
					view.setOnClickListener(this);
				}
			}
}}

