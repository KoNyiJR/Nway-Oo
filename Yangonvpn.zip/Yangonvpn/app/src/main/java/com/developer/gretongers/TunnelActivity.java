package com.developer.gretongers;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import com.developer.gretongers.*;
import com.developer.gretongers.config.Settings;
import com.developer.gretongers.view.MaterialButton;
import android.view.Menu;
import android.view.MenuItem;
import com.developer.gretongers.logger.SkStatus;
import android.widget.Toast;

public class TunnelActivity extends AppCompatActivity implements View.OnClickListener {

	private Toolbar toolbar_main;
	private RadioButton btnDirect;
    private RadioButton btnHTTP;
	private RadioButton btnSSL;
	private RadioButton btnSlowDNS;
	private RadioButton btnSSLHTTP;
    private RadioButton btnSSL_PAY;
	private CheckBox customPayload;
	private Settings mConfig;
	private SharedPreferences prefs;
	private MaterialButton save;
	private TextView mTextView;

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.btnDirect:
				btnHTTP.setChecked(false);
				btnSSL.setChecked(false);
				btnSSL_PAY.setChecked(false);
				btnSSLHTTP.setChecked(false);
				btnSlowDNS.setChecked(false);
				customPayload.setEnabled(true);
				if (customPayload.isChecked()) {
					mTextView.setText(getString(R.string.direct) + getString(R.string.custom_payload1));
				} else {
					mTextView.setText(getString(R.string.direct));			
				}
				break;

			case R.id.btnHTTP:
				btnDirect.setChecked(false);
				btnSSL.setChecked(false);
				btnSSL_PAY.setChecked(false);
				btnSSLHTTP.setChecked(false);
                btnSlowDNS.setChecked(false);
				customPayload.setEnabled(true);
				if (customPayload.isChecked()) {
					mTextView.setText(getString(R.string.http) + getString(R.string.custom_payload1));
				} else {
					mTextView.setText(getString(R.string.http));			
				}
                break;

			case R.id.btnSSL:
				btnHTTP.setChecked(false);
				btnDirect.setChecked(false);
				btnSSL_PAY.setChecked(false);
				btnSSLHTTP.setChecked(false);
                btnSlowDNS.setChecked(false);
				customPayload.setEnabled(false);
				customPayload.setChecked(false);
				mTextView.setText(getString(R.string.ssl));
                break;

			case R.id.btnSlowDNS:
				btnHTTP.setChecked(false);
				btnSSL.setChecked(false);
				btnDirect.setChecked(false);
                btnSSL_PAY.setChecked(false);
				btnSSLHTTP.setChecked(false);
				customPayload.setEnabled(false);
				customPayload.setChecked(false);
				mTextView.setText(getString(R.string.slowdns));		
                break;

            case R.id.btnSSLPay:
                btnDirect.setChecked(false);
                btnHTTP.setChecked(false);
                btnSSL.setChecked(false);
                btnSSLHTTP.setChecked(false);
                btnSlowDNS.setChecked(false);
                customPayload.setEnabled(false);
                customPayload.setChecked(true);
				mTextView.setText(getString(R.string.sslpay) + getString(R.string.custom_payload1));		
                break;

			case R.id.btnSSLHTTP:
                btnDirect.setChecked(false);
                btnHTTP.setChecked(false);
                btnSSL_PAY.setChecked(false);
                btnSSL.setChecked(false);
                btnSlowDNS.setChecked(false);
                customPayload.setEnabled(false);
                customPayload.setChecked(true);
				mTextView.setText(getString(R.string.webssl) + getString(R.string.custom_payload1));		

                break;

			case R.id.customPayload:
				if (customPayload.isChecked()) {
					if (btnDirect.isChecked()) {
						mTextView.setText(getString(R.string.direct) + getString(R.string.custom_payload1));
					} else if (btnHTTP.isChecked()) {
						mTextView.setText(getString(R.string.http) + getString(R.string.custom_payload1));
					} else if (btnSSL.isChecked()) {
						mTextView.setText(getString(R.string.ssl) + getString(R.string.custom_payload1));
					} else if (btnSSLHTTP.isChecked()) {
						mTextView.setText(getString(R.string.webssl) + getString(R.string.custom_payload1));
					} else if (btnSSL_PAY.isChecked()) {
						mTextView.setText(getString(R.string.sslpay) + getString(R.string.custom_payload1));

					}
				} else {
					if (btnDirect.isChecked()) {
						mTextView.setText(getString(R.string.direct));
					} else if (btnHTTP.isChecked()) {
						mTextView.setText(getString(R.string.http));
					} else if (btnSSL.isChecked()) {
						mTextView.setText(getString(R.string.ssl));
					} else if (btnSSLHTTP.isChecked()) {
						mTextView.setText(getString(R.string.webssl));
					} else if (btnSSL_PAY.isChecked()) {
						mTextView.setText(getString(R.string.sslpay));

					}
				}
				break;

			case R.id.saveButton:
				doSave();	
				break;
		}
	}

	private void doSave() {
		SharedPreferences.Editor edit = mConfig.getPrefsPrivate().edit();

		if (btnDirect.isChecked()) {
			edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);	

		} else if (btnHTTP.isChecked()) {
			edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_PROXY);	

		} else if (btnSSL.isChecked()) {
			edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_PROXY);	

        } else if (btnSSL_PAY.isChecked()) {
            edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_PAY);  

	    } else if (btnSlowDNS.isChecked()) {
			edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SLOWDNS);	

		} else if (btnSSLHTTP.isChecked()) {
			edit.putInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSL_HTTP);

	    }	

		if (customPayload.isChecked()) {
			edit.putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, false);

		} else {
			edit.putBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true);
		}
		edit.apply();
		startActivity(new Intent(this, MainActivity.class));
		MainActivity.updateMainViews(getApplicationContext());
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tunnel_type);
		mConfig = new Settings(this);
		prefs = mConfig.getPrefsPrivate();
		toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
		setSupportActionBar(toolbar_main);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		setupButton();
	}

	private void setupButton() {
		mTextView = (TextView) findViewById(R.id.tunneltypeTextView1);
		btnDirect = (RadioButton) findViewById(R.id.btnDirect);
		btnDirect.setOnClickListener(this);
		btnHTTP = (RadioButton) findViewById(R.id.btnHTTP);
		btnHTTP.setOnClickListener(this);
		btnSSL = (RadioButton) findViewById(R.id.btnSSL);
		btnSSL.setOnClickListener(this);
        btnSSL_PAY = (RadioButton) findViewById(R.id.btnSSLPay);
		btnSSL_PAY.setOnClickListener(this);
		btnSlowDNS = (RadioButton) findViewById(R.id.btnSlowDNS);
		btnSlowDNS.setOnClickListener(this);
		btnSSLHTTP = (RadioButton) findViewById(R.id.btnSSLHTTP);
		btnSSLHTTP.setOnClickListener(this);

		customPayload = (CheckBox) findViewById(R.id.customPayload);
		customPayload.setOnClickListener(this);

		save = (MaterialButton) findViewById(R.id.saveButton);
		save.setOnClickListener(this);

		int tunnelType = prefs.getInt(Settings.TUNNELTYPE_KEY, Settings.bTUNNEL_TYPE_SSH_DIRECT);

	    customPayload.setChecked(!prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true));

		switch (tunnelType) {
			case Settings.bTUNNEL_TYPE_SSH_DIRECT:
				btnDirect.setChecked(true);
				btnHTTP.setChecked(false);
				btnSSL.setChecked(false);
				btnSSL_PAY.setChecked(false);
				btnSSLHTTP.setChecked(false);
				btnSlowDNS.setChecked(false);
				customPayload.setEnabled(true);

				if (!prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
					mTextView.setText(getString(R.string.direct) + getString(R.string.custom_payload1));
				} else {
					mTextView.setText(getString(R.string.direct));			
				}
				break;

			case Settings.bTUNNEL_TYPE_SSH_PROXY:
				btnHTTP.setChecked(true);
				btnDirect.setChecked(false);
				btnSSL.setChecked(false);
                btnSSL_PAY.setChecked(false);
				btnSlowDNS.setChecked(false);
				customPayload.setEnabled(true);
				if (!prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
					mTextView.setText(getString(R.string.http) + getString(R.string.custom_payload1));
				} else {
					mTextView.setText(getString(R.string.http));			
				}
				break;

			case Settings.bTUNNEL_TYPE_SSL_PROXY:
				btnSSL.setChecked(true);
				btnHTTP.setChecked(false);
				btnDirect.setChecked(false);
                btnSSL_PAY.setChecked(false);
				btnSSLHTTP.setChecked(false);
				btnSlowDNS.setChecked(false);
				customPayload.setEnabled(false);
				customPayload.setChecked(false);
				mTextView.setText(getString(R.string.ssl));			
				break;

            case Settings.bTUNNEL_TYPE_SSL_PAY:
                btnSSL_PAY.setChecked(true);
				btnSSLHTTP.setChecked(false);
                btnSSL.setChecked(false);
                btnHTTP.setChecked(false);
                btnDirect.setChecked(false);
                btnSlowDNS.setChecked(false);
                customPayload.setEnabled(false);
                customPayload.setChecked(true);
                mTextView.setText(getString(R.string.sslpay ) + getString(R.string.custom_payload1));         
				break;

			case Settings.bTUNNEL_TYPE_SLOWDNS:
				btnSlowDNS.setChecked(true);
				btnHTTP.setChecked(false);
				btnSSL.setChecked(false);
				btnDirect.setChecked(false);
				customPayload.setEnabled(false);
				customPayload.setChecked(false);
				mTextView.setText(getString(R.string.slowdns));		
				break;

			case Settings.bTUNNEL_TYPE_SSL_HTTP:
                btnSSLHTTP.setChecked(true);
                btnSSL_PAY.setChecked(false);
                btnSSL.setChecked(false);
                btnHTTP.setChecked(false);
                btnDirect.setChecked(false);
                btnSlowDNS.setChecked(false);
                customPayload.setEnabled(false);
                customPayload.setChecked(true);
                mTextView.setText(getString(R.string.webssl ) + getString(R.string.custom_payload1));
				break;
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu,add items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.tunnel_menu, menu);//Menu ResourceFile
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.miLimparConfig:
                if (!SkStatus.isTunnelActive()) {
                    Settings.clearSettings(TunnelActivity.this);
                    SkStatus.clearLog();	
                    MainActivity.updateMainViews(getApplicationContext());
                    btnDirect.setEnabled(true);
                    btnDirect.setChecked(true);
                    btnHTTP.setChecked(false);
                    btnSSL.setChecked(false);
                    btnSSL_PAY.setChecked(false);
					btnSSLHTTP.setChecked(false);
                    btnSlowDNS.setChecked(false);
                    customPayload.setChecked(false);
                    customPayload.setEnabled(true);

                    if (!prefs.getBoolean(Settings.PROXY_USAR_DEFAULT_PAYLOAD, true)) {
                        mTextView.setText(getString(R.string.direct) + getString(R.string.custom_payload1));
                    } else {
                        mTextView.setText(getString(R.string.direct));          
                    }
                } else {
                    Toast.makeText(this, R.string.error_tunnel_service_execution, Toast.LENGTH_SHORT)
                        .show();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
