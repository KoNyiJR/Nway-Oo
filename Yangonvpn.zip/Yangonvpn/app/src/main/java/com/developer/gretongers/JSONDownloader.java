package com.developer.gretongers;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
//
//  import org.apache.http.HttpEntity;
//  import org.apache.http.HttpResponse;
//  import org.apache.http.client.HttpClient;
//  import org.apache.http.client.methods.HttpPost;
//  import org.apache.http.impl.client.DefaultHttpClient;
//
import android.util.Log;
import java.net.*;
import java.io.*;


public class JSONDownloader {
	
	public static String download(String url){
		StringBuffer result = new StringBuffer();
		try
		{
			HttpURLConnection connection = ((HttpURLConnection) new URL(url).openConnection());
			BufferedReader reader = new BufferedReader(
			new InputStreamReader(connection.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null)
			result.append(line).append("\n");
			
			reader.close();
			connection.disconnect();
			
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return "";
		}
		
		return result.toString();
	}
	
}