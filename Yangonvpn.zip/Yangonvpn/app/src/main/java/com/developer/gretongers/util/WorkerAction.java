package com.developer.gretongers.util;

public interface WorkerAction {
    void runFirst();

    void runLast();
}
