package com.developer.gretongers;

public class PostItemData {
	
	public String name="";
	public String flag="";
	public String serverhost="";
	public String sshport="";
	public String username="";
	public String password="";
	
	
	
	
	public PostItemData(String name,String flag,String serverhost,String sshport,String username,String password){
		
		this.name=name;
		
		
		this.flag=flag;
		
		this.serverhost=serverhost;
		this.sshport=sshport;
		this.username=username;
		this.password=password;
		
		
		
	}
	
	//public void add(int i, AdView adView) {
	//}
	
}